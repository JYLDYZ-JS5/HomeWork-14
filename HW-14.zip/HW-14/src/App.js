import Disco from "./components/INDEX"
function App() {
  return <>
  
  <Disco />
  
  </>
}

export default App
